import logo from './logo.svg';
import './App.css';

import CreateAccount from './components/createaccount/createaccount';
import SearchAccount from './components/searchaccount/searchaccount';
import ShowAccount from './components/showaccount/showaccount';
import Deposit from './components/deposit/deposit';
import Withdraw from './components/withdraw/withdraw';


function App() {
  return (
    <div className="App">
      <CreateAccount/><br/>
      <SearchAccount/><br/>
      <ShowAccount/><br/>
      <Deposit/><br/>
      <Withdraw/><br/>
      
    </div>
  );
}

export default App;
