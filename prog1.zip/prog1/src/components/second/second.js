import React, {Component} from 'react';
const Second = () => {
  return(
    <div>
      <p>This is My Second Component Thank You All...</p>
    </div>
  )
}
export default Second;