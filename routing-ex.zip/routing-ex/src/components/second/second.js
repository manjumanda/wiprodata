import React, {Component} from 'react';
import Menu from '../menu/menu';
const Second = () => {
  return(
    <div>
      <Menu/>
      <p>This is My Second Component Thank You All...</p>
    </div>
  )
}
export default Second;